import axios from "axios";
import store from "../store/store"; //If using Redux
import { setAccessToken, logout } from "../features/auth/authSlice";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE,
  withCredentials: true, //It require if backend is setting HttpOnly cookies
});

// To attach the access token if available
api.interceptors.request.use(
  (config) => {
    const token = store.getState().auth.accessToken; // If holding access token in Redux
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (err) => Promise.reject(err)
);

// To handle token refresh on 401 responses
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
  failedQueue.forEach((prom) =>
    error ? prom.reject(error) : prom.resolve(token)
  );
  failedQueue = [];
};

api.interceptors.response.use(
  (res) => res,
  async (err) => {
    const originalRequest = err.config;
    if (err.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise(function (resolve, reject) {
          failedQueue.push({ resolve, reject });
        })
          .then((token) => {
            originalRequest.headers.Authorization = "Bearer " + token;
            return api(originalRequest);
          })
          .catch((e) => Promise.reject(e));
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        //If backend has httpOnly cookie setup for refresh endpoint
        const r = await axios.post(
          `${import.meta.env.VITE_API_BASE}/auth/refresh`,
          {},
          { withCredentials: true }
        );
        const newToken = r.data.accessToken;
        store.dispatch(setAccessToken(newToken));
        api.defaults.headers.common["Authorization"] = "Bearer " + newToken;
        processQueue(null, newToken);
        return api(originalRequest);
      } catch (e) {
        processQueue(e, null);
        store.dispatch(logout());
        return Promise.reject(e);
      } finally {
        isRefreshing = false;
      }
    }
    return Promise.reject(err);
  }
);

export default api;
